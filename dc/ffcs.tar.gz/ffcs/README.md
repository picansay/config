# make build
# docker tag ffcs localhost/ffcs
# docker push localhost/ffcs
# make clean
